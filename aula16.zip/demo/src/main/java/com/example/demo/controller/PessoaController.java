package com.example.demo.controller;

import com.example.demo.domain.Pessoa;
import com.example.demo.repository.PessoaRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PessoaController {

    PessoaRepository repository = new PessoaRepository();

    @GetMapping("/criar")
    public void criarTabela() {
        System.out.println("criando tabela");
        repository.createTable();
    }

    @GetMapping("/criar-pessoa")
    public void criarPessoa() {
        Pessoa pessoa = new Pessoa("1", "Fulano");

        System.out.println("salvando pessoa");
        repository.save(pessoa);
    }

    @GetMapping("/retornar-pessoas")
    public List<Pessoa> findAllPessoas() {
        System.out.println("retornando todas as pessoas");

        return repository.findAll();
    }
}