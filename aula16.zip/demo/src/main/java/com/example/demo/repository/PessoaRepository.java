package com.example.demo.repository;

import com.example.demo.domain.Pessoa;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PessoaRepository {
    public void createTable() {
        Connection connection = null;
        Statement statement = null;
        try {
            //passo 1: registrar driver JDBC
            System.out.println("registrando driver");
            Class.forName("org.h2.Driver");
            //passo 2: abrir uma conexao com BD
            System.out.println("abrindo conexao");
            connection = DriverManager.getConnection(
                    "jdbc:h2:mem:testdb",
                    "admin",
                    "123456"
            );
            //passo 3: executar sql
            statement = connection.createStatement();
            String sql = "create table pessoa  ( " +
                    "id varchar(255) not null, " +
                    "nome varchar(255) not null, " +
                    "primary key(id) " +
                    ")";
            System.out.println("executando sql");
            statement.execute(sql);
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        }
    }

    public void save(Pessoa pessoa) {
        Connection connection = null;
        Statement statement = null;
        try {
            //passo 1: registrar driver JDBC
            System.out.println("registrando driver");
            Class.forName("org.h2.Driver");
            //passo 2: abrir uma conexao com BD
            System.out.println("abrindo conexao");
            connection = DriverManager.getConnection(
                    "jdbc:h2:mem:testdb",
                    "admin",
                    "123456"
            );
            //passo 3: executar sql
            statement = connection.createStatement();
            String sql = "insert into pessoa (id, nome) "
                    + "values ('"
                    + pessoa.getId()
                    + "', '"
                    + pessoa.getNome()
                    + "')";
            System.out.println("executando sql");
            statement.execute(sql);
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        }
    }

    public List<Pessoa> findAll() {
        List<Pessoa> pessoasLista = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            //passo 1: registrar driver JDBC
            System.out.println("registrando driver");
            Class.forName("org.h2.Driver");
            //passo 2: abrir uma conexao com BD
            System.out.println("abrindo conexao");
            connection = DriverManager.getConnection(
                    "jdbc:h2:mem:testdb",
                    "admin",
                    "123456"
            );
            //passo 3: executar sql
            statement = connection.createStatement();

            String sql = "select * from pessoa";

            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String id = resultSet.getString("id");
                String nome = resultSet.getString("nome");

                Pessoa pessoa = new Pessoa(id, nome);

                pessoasLista.add(pessoa);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            try {
                resultSet.close();
                statement.close();
                connection.close();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        }

        return pessoasLista;
    }

}
